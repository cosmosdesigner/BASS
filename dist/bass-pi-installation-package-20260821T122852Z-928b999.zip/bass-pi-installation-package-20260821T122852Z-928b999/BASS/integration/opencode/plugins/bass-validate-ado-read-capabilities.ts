import { existsSync, readFileSync } from "node:fs"
import { join } from "node:path"
import { type Plugin, tool } from "@opencode-ai/plugin"

const categories = ["Wiki", "Work Item", "Relations", "History/comments"] as const
type Category = typeof categories[number]
type Mapping = { tool_name: string; supported_input: string; verified_read_only: boolean; verification_date: string; valid: boolean }

function section(text: string, heading: string) { return text.match(new RegExp(`^## ${heading.replace("/", "\\/")}[ \\t]*\\r?\\n([\\s\\S]*?)(?=^## |$(?![\\s\\S]))`, "m"))?.[1] || "" }
function field(text: string, name: string) { return text.match(new RegExp(`^${name}:[ \\t]*(\\S(?:.*\\S)?)[ \\t]*$`, "m"))?.[1].trim() || "" }
function parse(text: string): Record<Category, Mapping> { return Object.fromEntries(categories.map((category) => { const block = section(text, category), tool_name = field(block, "tool_name"), supported_input = field(block, "supported_input"), verification_date = field(block, "verification_date"), verified_read_only = /^verified_read_only:\s*true\s*$/mi.test(block), safeToolName = /^[A-Za-z0-9_-]+$/.test(tool_name), wellFormed = block.split(/\r?\n/).every((line) => !line.trim() || /^(tool_name|supported_input|verified_read_only|verification_date):/.test(line.trim())); return [category, { tool_name, supported_input, verified_read_only, verification_date, valid: Boolean(wellFormed && safeToolName && supported_input && verified_read_only && verification_date) }] })) as Record<Category, Mapping> }
function gaps(brief: string) { return brief.split(/\r?\n/).flatMap((line) => { const match = line.match(/^- Expected source: (Functional ADO Wiki|Technical ADO Wiki|ADO Work Item|ADO relations|ADO history) \(([^)]+)\)/); return match ? [{ category: match[1], input: match[2] }] : [] }) }
function categoryFor(category: string): Category { return category.includes("Wiki") ? "Wiki" : category === "ADO Work Item" ? "Work Item" : category === "ADO relations" ? "Relations" : "History/comments" }

export function validateAdoReadCapabilities({ projectDirectory, brief }: { projectDirectory: string; brief: string }) {
  const path = join(projectDirectory, "project-context", "ado-read-capabilities.md"), mappings = parse(existsSync(path) ? readFileSync(path, "utf8") : "")
  const permissionFragment = [`"ado_*": deny`, ...categories.filter((category) => mappings[category].valid).map((category) => `"${mappings[category].tool_name}": allow`)].join("\n")
  const dispatch = gaps(brief).flatMap((gap) => { const mapping = mappings[categoryFor(gap.category)]; return mapping.valid ? [{ category: gap.category, tool_name: mapping.tool_name, input: gap.input }] : [] })
  const unmappedGaps = gaps(brief).flatMap((gap) => mappings[categoryFor(gap.category)].valid ? [] : [`${gap.category} (${gap.input})`])
  return { mappings, permissionFragment, dispatch, unmappedGaps }
}

export const BassValidateAdoReadCapabilitiesPlugin: Plugin = async () => ({ tool: { bass_validate_ado_read_capabilities: tool({ description: "Deterministically validate project ADO read mappings and plan Reader dispatch without MCP calls.", args: { projectDirectory: tool.schema.string(), brief: tool.schema.string() }, async execute(args) { return JSON.stringify(validateAdoReadCapabilities(args)) } }) } })
